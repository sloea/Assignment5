package iss.java.mail;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Properties;

import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;

public class JavaMail2014302580087 implements IMailService {
	private static Properties props = null; 
	private Session session;
	private MailAuthenticator authenticator;
	private String username="15882669568@163.com";
	private String password="mhbdrkdeallgetyq";
	private Folder folder;
	private Store store;

    /**
     * 初始化并连接邮件服务器
     * 使用smtp协议
     * 链接163邮箱
     * @throws MessagingException 初始化或连接异常
     */
	public void connect() throws MessagingException {
		// TODO 自动生成的方法存根
		props = new Properties(); 
        props.setProperty("mail.transport.protocol", "smtp");// 邮件发送协议  
        props.setProperty("mail.smtp.host", "smtp.163.com");// SMTP邮件服务器 
        props.setProperty("mail.smtp.port", "25");// SMTP邮件服务器默认端口  
        props.setProperty("mail.smtp.auth", "true");// 是否要求身份认证  
        props.setProperty("mail.debug","true");// 是否启用调试模式 
       
	}
	 /**
     * 发送单封邮件
     * @param recipient 收件人邮箱地址
     * @param subject 邮件主题
     * @param content 邮件正文
     * @throws MessagingException 发送邮件错误
     */
	public void send(String recipient, String subject, Object content)
			throws MessagingException {
		// TODO 自动生成的方法存根
		authenticator = new MailAuthenticator(username, password);
	    session = Session.getInstance(props, authenticator);// 创建session
        MimeMessage message = new MimeMessage(session);
        // 设置发信人
        message.setFrom(new InternetAddress(username));
        // 设置收件人
        message.setRecipient(RecipientType.TO, new InternetAddress(recipient));
        // 设置主题
        message.setSubject(subject);
        // 设置邮件内容
        message.setContent(content.toString(), "text/html;charset=utf-8");
        // 发送
        Transport.send(message);

	}
	 /**
     * 询问服务器是否有新邮件到达
     * @return 布朗值，指示是否有新邮件
     * @throws MessagingException 询问服务器出错
     */
	public boolean listen() throws MessagingException {
		// TODO 自动生成的方法存根
		props.setProperty("mail.store.protocol", "imap");  
        props.setProperty("mail.imap.host", "imap.163.com");  
        props.setProperty("mail.imap.port", "143");
        Session session = Session.getInstance(props);
        Store store = session.getStore("imap");// 创建IMAP协议的Store对象 
        store.connect(username, password); // 连接邮件服务器
        Folder folder = store.getFolder("INBOX");// 获得收件箱 
        folder.open(Folder.READ_WRITE);// 以读写模式打开收件箱 
        Message[] messages = folder.getMessages();// 获得收件箱的邮件列表 
		if (messages!=null){
			return true;
		}
		else{
			return false;
		}
	}
	/**
     * 接收自动回复的内容，并转换为字符串
     * 注：用你能想到的任意方法寻找回复邮件均可，并不一定要用到这两个参数
     * @param sender 自动回复的发件人邮箱地址
     * @param subject 自动回复的主题
     * @return 自动回复的内容字符串
     * @throws MessagingException 查询邮件异常
     * @throws IOException 下载邮件异常
     */
	public String getReplyMessageContent(String sender, String subject)
			throws MessagingException, IOException {
		// TODO 自动生成的方法存根
		Message[] messages = folder.getMessages(1,2);

        int mailCounts = messages.length;
        for(int i = 0; i < mailCounts; i++) {

            String m_subject = messages[i].getSubject();
            String from = (messages[i].getFrom()[0]).toString();

            System.out.println("第 " + (i+1) + "封邮件的主题：" + m_subject);
            System.out.println("第 " + (i+1) + "封邮件的发件人地址：" + from);

            System.out.println("是否打开该邮件(yes/no)?：");
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            String input = br.readLine();
            if("yes".equalsIgnoreCase(input)) {
                // 直接输出到控制台中
                messages[i].writeTo(System.out);
            }
        }
        folder.close(false);
        store.close();
		return null;
	}

}
